PHANTOM PANEL — BUILD PACKAGE
=============================

Based on the supplied AVM-PANEL package. The Flask application routes and existing
feature set are retained; the user/admin shells receive a Pure White + Blue theme.

INSTALL
-------
Extract the ZIP, enter the extracted folder, then run:
  sudo bash install.sh

Installer menu:
  1. Install Phantom Panel
  2. Uninstall Phantom Panel
  0. Exit

Panel URL after installation:
  https://YOUR_SERVER_IP

IMPORTANT
---------
- The installer creates a self-signed HTTPS certificate for the server IP.
  HTTPS traffic is encrypted, but browsers will warn that the certificate is
  not trusted. Use a domain and a trusted certificate for production.
- Application listens on localhost:3000 behind Nginx on ports 80/443.
- Persistent database: /var/lib/phantom-panel/phantom.db
- Application files: /opt/phantom-panel
- Existing AVM application functionality is retained; this package has not
  been integration-tested against your live VPS/node environment.
- Change administrator credentials immediately after first login.
- Keep .env private; it contains the application secret/encryption key.
- Use only on VPS nodes and systems you own or are authorized to administer.
