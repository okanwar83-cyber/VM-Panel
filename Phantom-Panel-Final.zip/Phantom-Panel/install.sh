#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/phantom-panel"
DATA_DIR="/var/lib/phantom-panel"
SERVICE="phantom-panel"
PORT="3000"
PANEL_PORT="443"

banner() {
  clear 2>/dev/null || true
  printf '\n'
  echo '  ██████╗ ██╗  ██╗ █████╗ ███╗   ██╗████████╗ ██████╗ ███╗   ███╗'
  echo '  ██╔══██╗██║  ██║██╔══██╗████╗  ██║╚══██╔══╝██╔═══██╗████╗ ████║'
  echo '  ██████╔╝███████║███████║██╔██╗ ██║   ██║   ██║   ██║██╔████╔██║'
  echo '  ██╔═══╝ ██╔══██║██╔══██║██║╚██╗██║   ██║   ██║   ██║██║╚██╔╝██║'
  echo '  ██║     ██║  ██║██║  ██║██║ ╚████║   ██║   ╚██████╔╝██║ ╚═╝ ██║'
  echo '  ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝'
  echo '                         PHANTOM PANEL'
  echo '                  VPS MANAGEMENT PLATFORM'
  echo '---------------------------------------------------------------'
}
need_root(){ [[ "$EUID" -eq 0 ]] || { echo "Run as root: sudo bash install.sh"; exit 1; }; }

install_panel() {
  need_root
  local src; src="$(cd "$(dirname "$0")" && pwd)"
  [[ -f "$src/hvm.py" && -f "$src/requirements.txt" ]] || { echo "Package files not found beside install.sh."; return 1; }
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y python3 python3-venv python3-pip build-essential curl ca-certificates nginx openssl
  mkdir -p "$APP_DIR" "$DATA_DIR"
  cp -a "$src/." "$APP_DIR/"
  python3 -m venv "$APP_DIR/.venv"
  "$APP_DIR/.venv/bin/pip" install --upgrade pip wheel
  "$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
  if [[ ! -f "$APP_DIR/.env" ]]; then
    SECRET="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
    cat > "$APP_DIR/.env" <<EOF
PANEL_NAME=Phantom Panel
PANEL_DEVELOPER=Phantom Panel
HOST=127.0.0.1
PORT=${PORT}
SECRET_KEY=${SECRET}
DATABASE_PATH=${DATA_DIR}/phantom.db
EOF
    chmod 600 "$APP_DIR/.env"
  fi
  # Self-signed IP certificate: HTTPS encryption is enabled; browsers will show a trust warning until a trusted domain certificate is configured.
  mkdir -p /etc/ssl/phantom-panel
  if [[ ! -f /etc/ssl/phantom-panel/fullchain.pem ]]; then
    PUBLIC_IP="$(curl -4fsS --max-time 8 https://api.ipify.org || echo 127.0.0.1)"
    openssl req -x509 -nodes -days 825 -newkey rsa:2048 \
      -keyout /etc/ssl/phantom-panel/privkey.pem \
      -out /etc/ssl/phantom-panel/fullchain.pem \
      -subj "/CN=${PUBLIC_IP}" \
      -addext "subjectAltName=IP:${PUBLIC_IP}"
    chmod 600 /etc/ssl/phantom-panel/privkey.pem
  fi
  cat > /etc/nginx/sites-available/phantom-panel <<'EOF'
server {
    listen 80 default_server;
    server_name _;
    return 301 https://$host$request_uri;
}
server {
    listen 443 ssl default_server;
    server_name _;
    ssl_certificate /etc/ssl/phantom-panel/fullchain.pem;
    ssl_certificate_key /etc/ssl/phantom-panel/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    client_max_body_size 100M;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 3600;
    }
}
EOF
  ln -sf /etc/nginx/sites-available/phantom-panel /etc/nginx/sites-enabled/phantom-panel
  rm -f /etc/nginx/sites-enabled/default
  cat > "/etc/systemd/system/${SERVICE}.service" <<EOF
[Unit]
Description=Phantom Panel VPS Manager
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/.env
ExecStart=${APP_DIR}/.venv/bin/python ${APP_DIR}/hvm.py
Restart=on-failure
RestartSec=5
User=root
[Install]
WantedBy=multi-user.target
EOF
  nginx -t
  systemctl daemon-reload
  systemctl enable --now "$SERVICE"
  systemctl enable --now nginx
  systemctl restart nginx
  echo
  echo "Phantom Panel installation finished."
  echo "Panel URL: https://$(curl -4fsS --max-time 8 https://api.ipify.org || hostname -I | awk '{print $1}')"
  echo "Note: this first-run certificate is self-signed; configure a trusted domain certificate to remove the browser warning."
}
uninstall_panel() {
  need_root
  systemctl disable --now "$SERVICE" 2>/dev/null || true
  rm -f "/etc/systemd/system/${SERVICE}.service"
  rm -f /etc/nginx/sites-enabled/phantom-panel /etc/nginx/sites-available/phantom-panel
  systemctl daemon-reload
  nginx -t && systemctl reload nginx || true
  rm -rf "$APP_DIR"
  echo "Phantom Panel application removed. Database retained at ${DATA_DIR}."
}
while true; do
  banner
  echo "  [1] Install Phantom Panel"
  echo "  [2] Uninstall Phantom Panel"
  echo "  [0] Exit"
  echo "---------------------------------------------------------------"
  read -r -p "Select option: " choice
  case "$choice" in
    1) install_panel ;;
    2) uninstall_panel ;;
    0) exit 0 ;;
    *) echo "Invalid option." ;;
  esac
  echo
  read -r -p "Press Enter to continue..." _
done
